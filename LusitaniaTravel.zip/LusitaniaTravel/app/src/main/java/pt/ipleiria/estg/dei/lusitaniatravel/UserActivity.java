package pt.ipleiria.estg.dei.lusitaniatravel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class UserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
    }

    public void onClickFavoritos(View view) {
        Intent intent = new Intent(this , FavoriteActivity.class);
        startActivity(intent);
    }

    public void onClickComentarios(View view) {
        Intent intent = new Intent (this , CommentsActivity.class);
        startActivity(intent);
    }

    public void onClickConfiguracoes(View view) {
        //Intent intent = new Intent(this , SettingsActivity.class); Implementar menu
        //startActivity(intent);
    }


    public void onClickFaturas(View view) {
        Intent intent = new Intent(this , myBillsActivity.class);
        startActivity(intent);
    }
}