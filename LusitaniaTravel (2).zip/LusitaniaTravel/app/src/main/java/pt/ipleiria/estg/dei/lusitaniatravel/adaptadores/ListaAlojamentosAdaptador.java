package pt.ipleiria.estg.dei.lusitaniatravel.adaptadores;

public class ListaAlojamentosAdaptador {
}
